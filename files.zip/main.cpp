#include "core/Window.h"
#include "core/InputHandler.h"
#include "core/Timer.h"
#include "rendering/Renderer.h"
#include "rendering/Camera.h"
#include "simulation/Spacecraft.h"
#include "simulation/Physics.h"
#include <iostream>
#include <iomanip>

// ─────────────────────────────────────────────────────────────────────────────
//  Scenario: low-Earth orbit deorbit burn → reentry → splashdown
//  Inspired by a Crew Dragon / Apollo-type ballistic capsule.
// ─────────────────────────────────────────────────────────────────────────────
static orbital::StateVector build_deorbit_state() {
    using namespace orbital;

    // Start on a circular orbit at 200 km altitude
    OrbitalElements circ;
    circ.sma  = constants::R_EARTH + 200e3;   // 200 km orbit
    circ.ecc  = 0.0;
    circ.inc  = glm::radians(28.5);            // KSC-like inclination
    circ.raan = 0.0;
    circ.aop  = 0.0;
    circ.ta   = 0.0;

    StateVector sv = OrbitalElementsConverter::to_state(circ);

    // Apply retrograde deorbit burn: Δv = -120 m/s (prograde direction)
    glm::dvec3 v_hat = glm::normalize(sv.velocity);
    sv.velocity += v_hat * -120.0;

    std::cout << "[Scenario] Circular orbit at 200 km, retrograde Δv = 120 m/s\n";
    std::cout << std::fixed << std::setprecision(3);
    std::cout << "  |pos| = " << glm::length(sv.position) / 1e3 << " km\n";
    std::cout << "  |vel| = " << glm::length(sv.velocity)       << " m/s\n";
    return sv;
}

// ─────────────────────────────────────────────────────────────────────────────
int main() {
    // ── Window ────────────────────────────────────────────────────────────────
    core::WindowConfig wcfg;
    wcfg.width  = 1280;
    wcfg.height = 720;
    wcfg.title  = "Orbital Reentry Simulation";
    wcfg.vsync  = true;
    wcfg.msaa   = true;

    core::Window window;
    if (!window.init(wcfg)) return 1;

    // ── Camera ────────────────────────────────────────────────────────────────
    render::Camera camera;

    // ── Input ─────────────────────────────────────────────────────────────────
    core::InputHandler input(window, camera);

    window.on_resize = [&](int w, int h) {
        // Renderer handles its own glViewport
    };

    // ── Renderer ──────────────────────────────────────────────────────────────
    render::Renderer renderer;
    if (!renderer.init(wcfg.width, wcfg.height)) return 1;

    window.on_resize = [&](int w, int h) {
        renderer.resize(w, h);
    };

    // ── Simulation ────────────────────────────────────────────────────────────
    orbital::SpacecraftConfig craft;
    craft.name       = "Capsule-1";
    craft.mass       = 9500.0;    // kg  (Dragon-like)
    craft.drag_coeff = 1.28;      // blunt capsule
    craft.ref_area   = 12.0;      // m²
    craft.lift_coeff = 0.15;

    orbital::Spacecraft spacecraft(craft);
    spacecraft.set_state(build_deorbit_state());

    // Pre-run simulation (accumulates full trajectory into telemetry vector)
    std::cout << "[Sim] Pre-computing trajectory…\n";
    spacecraft.run(
        86400.0,          // max 1 day
        10.0,             // record every 10 s
        [](const orbital::Telemetry& t) {
            // Print reentry events
            if (t.phase == orbital::SimPhase::REENTRY && (int(t.time) % 60 == 0)) {
                std::printf("  t=%7.0f s | alt=%6.1f km | v=%7.1f m/s | "
                            "Mach=%4.1f | G=%4.1f g | q=%6.0f Pa\n",
                    t.time, t.altitude / 1e3, t.speed,
                    t.mach, t.g_load, t.dynamic_pressure);
            }
        }
    );

    const auto& telem = spacecraft.telemetry();
    std::cout << "[Sim] Done — " << telem.size() << " telemetry points recorded.\n";

    // Upload full trail to GPU
    renderer.upload_trajectory(telem);

    // Replay cursor: index into telemetry vector
    size_t replay_idx  = 0;
    double replay_time = 0.0;  // accumulated sim-time for replay

    // ── Main loop ─────────────────────────────────────────────────────────────
    core::Timer frame_timer;

    while (!window.should_close() && !input.quit_requested) {
        window.poll_events();
        double real_dt = frame_timer.tick();

        // Camera reset hotkey
        if (input.reset_camera) { camera.reset(); input.reset_camera = false; }

        // Advance replay cursor
        if (!input.paused || input.step_requested) {
            double sim_dt = real_dt * input.time_scale;
            if (input.step_requested) { sim_dt = 10.0; input.step_requested = false; }
            replay_time += sim_dt;

            // Find the closest telemetry sample
            while (replay_idx + 1 < telem.size() &&
                   telem[replay_idx + 1].time <= replay_time)
                ++replay_idx;
        }

        // Update marker to current replay position
        if (!telem.empty()) {
            const auto& cur = telem[replay_idx];
            renderer.set_spacecraft_state(cur.state, cur.phase);
        }

        // Render
        renderer.render(camera, replay_time);
        window.swap_buffers();
    }

    renderer.shutdown();
    window.shutdown();
    return 0;
}
