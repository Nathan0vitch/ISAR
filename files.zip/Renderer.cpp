#include "rendering/Renderer.h"
#include "rendering/Shader.h"
#include "rendering/Camera.h"
#include "rendering/Mesh.h"
#include "simulation/Physics.h"
#include <glm/gtc/matrix_transform.hpp>
#include <vector>
#include <cmath>

namespace render {

// ── Embedded shader sources ───────────────────────────────────────────────────
static const char* EARTH_VERT = R"(
#version 330 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNorm;
layout(location=2) in vec2 aUV;
out vec3 vNorm;
out vec2 vUV;
uniform mat4 uModel, uView, uProj;
void main() {
    vNorm = mat3(transpose(inverse(uModel))) * aNorm;
    vUV   = aUV;
    gl_Position = uProj * uView * uModel * vec4(aPos, 1.0);
})";

static const char* EARTH_FRAG = R"(
#version 330 core
in vec3 vNorm;
in vec2 vUV;
out vec4 FragColor;
uniform vec3 uLightDir;
void main() {
    // Procedural Earth-like shading
    float lat = asin(normalize(vNorm).y);
    float lon = atan(vNorm.z, vNorm.x);

    // Base colour: deep ocean blue
    vec3 col = vec3(0.06, 0.15, 0.35);

    // Simple continent blobs via sin patterns
    float land = sin(lon * 3.0 + 1.0) * sin(lat * 4.0 + 0.5);
    land       = smoothstep(0.1, 0.5, land);
    col = mix(col, vec3(0.18, 0.35, 0.12), land);

    // Polar ice caps
    float pole = smoothstep(1.1, 1.4, abs(lat) * 2.2);
    col = mix(col, vec3(0.9, 0.95, 1.0), pole);

    // Diffuse lighting
    float diff = max(dot(normalize(vNorm), normalize(uLightDir)), 0.05);
    col *= (0.15 + 0.85 * diff);

    // Atmosphere rim glow
    float rim = 1.0 - abs(dot(normalize(vNorm), vec3(0.0, 0.0, 1.0)));
    col += vec3(0.1, 0.2, 0.5) * pow(rim, 4.0) * 0.4;

    FragColor = vec4(col, 1.0);
})";

static const char* TRAIL_VERT = R"(
#version 330 core
layout(location=0) in vec3  aPos;
layout(location=1) in float aPhase;  // 0=orbit 1=reentry
layout(location=2) in float aT;      // normalised time [0,1]
out vec4 vColor;
uniform mat4 uView, uProj;
void main() {
    // Colour: orbit=cyan, reentry gradient yellow→red
    vec3 orbitCol   = vec3(0.0, 0.8, 1.0);
    vec3 reentryCol = mix(vec3(1.0, 0.8, 0.0), vec3(1.0, 0.1, 0.0), aT);
    vec3 col = mix(orbitCol, reentryCol, aPhase);
    float alpha = mix(0.3, 1.0, aT);
    vColor = vec4(col, alpha);
    gl_Position = uProj * uView * vec4(aPos, 1.0);
})";

static const char* TRAIL_FRAG = R"(
#version 330 core
in  vec4 vColor;
out vec4 FragColor;
void main() { FragColor = vColor; })";

static const char* MARKER_VERT = R"(
#version 330 core
layout(location=0) in vec3 aPos;
uniform mat4 uView, uProj;
uniform vec3 uOffset;
void main() {
    gl_Position = uProj * uView * vec4(aPos + uOffset, 1.0);
    gl_PointSize = 10.0;
})";

static const char* MARKER_FRAG = R"(
#version 330 core
out vec4 FragColor;
uniform vec3 uColor;
void main() {
    vec2 p = gl_PointCoord - 0.5;
    if (dot(p,p) > 0.25) discard;
    FragColor = vec4(uColor, 1.0);
})";

static const char* AXES_VERT = R"(
#version 330 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aCol;
out vec3 vCol;
uniform mat4 uView, uProj;
void main() { vCol = aCol; gl_Position = uProj * uView * vec4(aPos, 1.0); })";

static const char* AXES_FRAG = R"(
#version 330 core
in vec3 vCol;
out vec4 FragColor;
void main() { FragColor = vec4(vCol, 0.6); })";

// ─────────────────────────────────────────────────────────────────────────────

Renderer::Renderer() = default;
Renderer::~Renderer() { shutdown(); }

bool Renderer::init(int w, int h) {
    viewport_w_ = w; viewport_h_ = h;

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_PROGRAM_POINT_SIZE);

    init_earth();
    init_trajectory_buffers();
    init_axes();
    return true;
}

void Renderer::init_earth() {
    earth_shader_ = std::make_unique<Shader>();
    earth_shader_->load_source(EARTH_VERT, EARTH_FRAG);

    auto mesh = Mesh::make_sphere(static_cast<float>(orbital::constants::R_EARTH), 80, 80);
    earth_mesh_ = std::make_unique<Mesh>(std::move(mesh));
}

void Renderer::init_trajectory_buffers() {
    trail_shader_ = std::make_unique<Shader>();
    trail_shader_->load_source(TRAIL_VERT, TRAIL_FRAG);
    glGenVertexArrays(1, &trail_vao_);
    glGenBuffers(1, &trail_vbo_);

    marker_shader_ = std::make_unique<Shader>();
    marker_shader_->load_source(MARKER_VERT, MARKER_FRAG);
    glGenVertexArrays(1, &marker_vao_);
    glGenBuffers(1, &marker_vbo_);

    // Unit sphere for marker (tiny)
    auto ms = Mesh::make_sphere(200e3f, 8, 8);  // 200 km radius marker
    // For simplicity we just use a point — marker drawn via gl_PointSize
    float pt[3] = {0,0,0};
    glBindVertexArray(marker_vao_);
    glBindBuffer(GL_ARRAY_BUFFER, marker_vbo_);
    glBufferData(GL_ARRAY_BUFFER, sizeof(pt), pt, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
    glEnableVertexAttribArray(0);
    glBindVertexArray(0);
}

void Renderer::init_axes() {
    axes_shader_ = std::make_unique<Shader>();
    axes_shader_->load_source(AXES_VERT, AXES_FRAG);

    // XYZ axes: 2 × 3 verts with colour
    float scale = 1.5e7f;
    float axes[] = {
        0,0,0, 1,0,0,   scale,0,0, 1,0,0,  // X red
        0,0,0, 0,1,0,   0,scale,0, 0,1,0,  // Y green
        0,0,0, 0,0,1,   0,0,scale, 0,0,1,  // Z blue
    };
    glGenVertexArrays(1, &axes_vao_);
    glGenBuffers(1, &axes_vbo_);
    glBindVertexArray(axes_vao_);
    glBindBuffer(GL_ARRAY_BUFFER, axes_vbo_);
    glBufferData(GL_ARRAY_BUFFER, sizeof(axes), axes, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6*sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6*sizeof(float), (void*)(3*sizeof(float)));
    glEnableVertexAttribArray(1);
    glBindVertexArray(0);
}

// ── Upload trajectory trail ───────────────────────────────────────────────────
void Renderer::upload_trajectory(const std::vector<orbital::Telemetry>& telem) {
    if (telem.empty()) return;

    // Struct: (x, y, z, phase_f, t_norm)
    struct TrailVert { float x, y, z, phase, t; };
    std::vector<TrailVert> verts;
    verts.reserve(telem.size());

    double t_max = telem.back().time;
    for (const auto& tel : telem) {
        float phase = (tel.phase == orbital::SimPhase::REENTRY) ? 1.0f : 0.0f;
        float t_n   = (t_max > 0.0) ? (float)(tel.time / t_max) : 0.0f;
        verts.push_back({
            (float)tel.state.position.x,
            (float)tel.state.position.y,
            (float)tel.state.position.z,
            phase, t_n
        });
    }
    trail_count_ = static_cast<GLsizei>(verts.size());

    glBindVertexArray(trail_vao_);
    glBindBuffer(GL_ARRAY_BUFFER, trail_vbo_);
    glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(TrailVert), verts.data(), GL_STATIC_DRAW);
    // pos
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(TrailVert), (void*)0);
    glEnableVertexAttribArray(0);
    // phase
    glVertexAttribPointer(1, 1, GL_FLOAT, GL_FALSE, sizeof(TrailVert), (void*)(3*sizeof(float)));
    glEnableVertexAttribArray(1);
    // t_norm
    glVertexAttribPointer(2, 1, GL_FLOAT, GL_FALSE, sizeof(TrailVert), (void*)(4*sizeof(float)));
    glEnableVertexAttribArray(2);
    glBindVertexArray(0);
}

// ── Set live spacecraft state ─────────────────────────────────────────────────
void Renderer::set_spacecraft_state(const orbital::StateVector& sv, orbital::SimPhase /*phase*/) {
    // The marker is drawn as a single point at the spacecraft's position
    float pt[3] = {
        (float)sv.position.x,
        (float)sv.position.y,
        (float)sv.position.z
    };
    glBindVertexArray(marker_vao_);
    glBindBuffer(GL_ARRAY_BUFFER, marker_vbo_);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(pt), pt);
    glBindVertexArray(0);
}

// ── Main render ───────────────────────────────────────────────────────────────
void Renderer::render(const Camera& cam, double /*sim_time*/) {
    glClearColor(0.02f, 0.02f, 0.06f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::mat4 V = cam.view();
    glm::mat4 P = cam.projection((float)viewport_w_ / viewport_h_);

    // ── Earth ─────────────────────────────────────────────────────────────────
    earth_shader_->use();
    earth_shader_->set_mat4("uModel", glm::mat4(1.0f));
    earth_shader_->set_mat4("uView",  V);
    earth_shader_->set_mat4("uProj",  P);
    earth_shader_->set_vec3("uLightDir", glm::normalize(glm::vec3(1.5f, 0.5f, 1.0f)));
    earth_mesh_->draw();

    // ── Trajectory trail ──────────────────────────────────────────────────────
    if (trail_count_ > 0) {
        trail_shader_->use();
        trail_shader_->set_mat4("uView", V);
        trail_shader_->set_mat4("uProj", P);
        glBindVertexArray(trail_vao_);
        glLineWidth(2.0f);
        glDrawArrays(GL_LINE_STRIP, 0, trail_count_);
        glBindVertexArray(0);
    }

    // ── Spacecraft marker ─────────────────────────────────────────────────────
    marker_shader_->use();
    marker_shader_->set_mat4("uView",   V);
    marker_shader_->set_mat4("uProj",   P);
    marker_shader_->set_vec3("uOffset", glm::vec3(0.0f));
    marker_shader_->set_vec3("uColor",  glm::vec3(1.0f, 0.9f, 0.2f));
    glBindVertexArray(marker_vao_);
    glDrawArrays(GL_POINTS, 0, 1);
    glBindVertexArray(0);

    // ── Reference axes ────────────────────────────────────────────────────────
    axes_shader_->use();
    axes_shader_->set_mat4("uView", V);
    axes_shader_->set_mat4("uProj", P);
    glBindVertexArray(axes_vao_);
    glDrawArrays(GL_LINES, 0, 6);
    glBindVertexArray(0);
}

void Renderer::resize(int w, int h) {
    viewport_w_ = w; viewport_h_ = h;
    glViewport(0, 0, w, h);
}

void Renderer::shutdown() {
    if (trail_vao_)  glDeleteVertexArrays(1, &trail_vao_);
    if (trail_vbo_)  glDeleteBuffers(1, &trail_vbo_);
    if (marker_vao_) glDeleteVertexArrays(1, &marker_vao_);
    if (marker_vbo_) glDeleteBuffers(1, &marker_vbo_);
    if (axes_vao_)   glDeleteVertexArrays(1, &axes_vao_);
    if (axes_vbo_)   glDeleteBuffers(1, &axes_vbo_);
}

} // namespace render
