#include "simulation/Spacecraft.h"
#include "simulation/OrbitalElements.h"
#include "simulation/Atmosphere.h"
#include <glm/glm.hpp>
#include <cmath>
#include <stdexcept>

#ifdef ORBITAL_DEBUG
#include <cstdio>
#endif

namespace orbital {

Spacecraft::Spacecraft(const SpacecraftConfig& cfg) : config_(cfg) {}

// ── Initialise from Keplerian elements ───────────────────────────────────────
void Spacecraft::set_orbit(const OrbitalElements& oe) {
    state_ = OrbitalElementsConverter::to_state(oe);
    time_  = 0.0;
    phase_ = SimPhase::ORBIT;
    telemetry_.clear();
}

void Spacecraft::set_state(const StateVector& sv, double t) {
    state_ = sv;
    time_  = t;
    phase_ = compute_phase(sv);
    telemetry_.clear();
}

// ── Altitude helper ───────────────────────────────────────────────────────────
double Spacecraft::altitude() const {
    return glm::length(state_.position) - constants::R_EARTH;
}

// ── Phase detection ───────────────────────────────────────────────────────────
SimPhase Spacecraft::compute_phase(const StateVector& sv) const {
    double h = glm::length(sv.position) - constants::R_EARTH;
    if (h <= 0.0)                       return SimPhase::LANDED;
    if (h < constants::KARMAN_LINE)     return SimPhase::REENTRY;
    return SimPhase::ORBIT;
}

// ── Gravity acceleration (ECI, two-body) ─────────────────────────────────────
glm::dvec3 Spacecraft::gravity(const glm::dvec3& pos) const {
    double r2  = glm::dot(pos, pos);
    double r3  = r2 * std::sqrt(r2);
    return pos * (-constants::MU_EARTH / r3);
}

// ── Aerodynamic acceleration ──────────────────────────────────────────────────
glm::dvec3 Spacecraft::aerodynamics(const StateVector& sv) const {
    double h   = glm::length(sv.position) - constants::R_EARTH;
    double rho = Atmosphere::density(h);
    if (rho <= 0.0) return glm::dvec3(0.0);

    double v_mag = glm::length(sv.velocity);
    if (v_mag < 1.0) return glm::dvec3(0.0);

    glm::dvec3 v_hat = sv.velocity / v_mag;

    // Ballistic coefficient β = m / (Cd · A)
    double q    = 0.5 * rho * v_mag * v_mag;
    double drag = q * config_.drag_coeff * config_.ref_area / config_.mass;

    glm::dvec3 a_drag = -v_hat * drag;

    // Lift (perpendicular to velocity, in the plane of v and radial vector)
    glm::dvec3 r_hat  = glm::normalize(sv.position);
    glm::dvec3 lift_dir = glm::normalize(r_hat - v_hat * glm::dot(r_hat, v_hat));
    double lift = q * config_.lift_coeff * config_.ref_area / config_.mass;
    glm::dvec3 a_lift = lift_dir * lift;

    return a_drag + a_lift;
}

// ── RK4 derivative function ───────────────────────────────────────────────────
StateVector Spacecraft::derivatives(const StateVector& sv) const {
    glm::dvec3 a = gravity(sv.position);
    if (compute_phase(sv) == SimPhase::REENTRY)
        a += aerodynamics(sv);
    return { sv.velocity, a };
}

// ── Single RK4 step ───────────────────────────────────────────────────────────
void Spacecraft::step(double dt) {
    if (phase_ == SimPhase::LANDED) return;

    auto k1 = derivatives(state_);
    auto k2 = derivatives(state_ + k1 * (dt * 0.5));
    auto k3 = derivatives(state_ + k2 * (dt * 0.5));
    auto k4 = derivatives(state_ + k3 * dt);

    state_ = state_ + (k1 + k2 * 2.0 + k3 * 2.0 + k4) * (dt / 6.0);
    time_ += dt;
    phase_ = compute_phase(state_);
}

// ── Telemetry snapshot ────────────────────────────────────────────────────────
Telemetry Spacecraft::current_telemetry() const {
    Telemetry t;
    t.time   = time_;
    t.state  = state_;
    t.phase  = phase_;

    double h = glm::length(state_.position) - constants::R_EARTH;
    double v = glm::length(state_.velocity);

    t.altitude         = h;
    t.speed            = v;
    t.mach             = v / Atmosphere::speed_of_sound(h);
    t.dynamic_pressure = Atmosphere::dynamic_pressure(h, v);
    t.heat_flux        = Atmosphere::heat_flux(h, v);

    // Drag deceleration
    double rho  = Atmosphere::density(h);
    double drag = 0.5 * rho * v * v * config_.drag_coeff * config_.ref_area / config_.mass;
    t.drag_accel = drag;
    t.g_load     = drag / 9.80665;

    return t;
}

// ── Full run loop ─────────────────────────────────────────────────────────────
void Spacecraft::run(double max_time, double rec_interval,
                     std::function<void(const Telemetry&)> cb) {
    // Use smaller time-step during reentry for accuracy
    constexpr double DT_ORBIT   = 10.0;   // s
    constexpr double DT_REENTRY =  0.5;   // s

    double next_record = 0.0;

    while (time_ < max_time && phase_ != SimPhase::LANDED) {
        double dt = (phase_ == SimPhase::REENTRY) ? DT_REENTRY : DT_ORBIT;
        // Don't overshoot max_time
        if (time_ + dt > max_time) dt = max_time - time_;

        step(dt);

        if (time_ >= next_record) {
            Telemetry tel = current_telemetry();
            telemetry_.push_back(tel);
            if (cb) cb(tel);
            next_record += rec_interval;

#ifdef ORBITAL_DEBUG
            std::printf("[t=%8.1f s] alt=%7.1f km  v=%7.1f m/s  Mach=%.1f  q=%.1f Pa  G=%.2f g  phase=%d\n",
                time_, tel.altitude / 1000.0, tel.speed, tel.mach,
                tel.dynamic_pressure, tel.g_load, (int)tel.phase);
#endif
        }
    }

    // Record final state
    telemetry_.push_back(current_telemetry());
}

} // namespace orbital
